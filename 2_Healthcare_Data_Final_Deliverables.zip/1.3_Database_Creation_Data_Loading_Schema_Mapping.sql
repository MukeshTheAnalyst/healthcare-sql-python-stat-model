-- -------------------------------------------------------------------
-- 1. Database Creation
-- -------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS healthcare_data;

USE healthcare_data;

-- -------------------------------------------------------------------
-- 2. Table Creation (Following Dependency Sequence)
-- -------------------------------------------------------------------

-- Level 1: Lookup Tables (No Foreign Keys)

-- Table: cities
CREATE TABLE cities (
    City_ID INT PRIMARY KEY,
    City VARCHAR(50) NOT NULL,
    State VARCHAR(50) NOT NULL
);

-- Table: departments
CREATE TABLE departments (
    Department_ID INT PRIMARY KEY,
    Department VARCHAR(50) NOT NULL
);

-- Table: diagnoses
CREATE TABLE diagnoses (
    Diagnosis_ID INT PRIMARY KEY,
    Diagnosis VARCHAR(50) NOT NULL
);

-- Table: insurance
CREATE TABLE insurance (
    Insurance_ID INT PRIMARY KEY,
    Insurance_Provider VARCHAR(50) NOT NULL
);

-- Table: procedures
CREATE TABLE procedures (
    Procedure_ID INT PRIMARY KEY,
    Procedure_Name VARCHAR(50) NOT NULL
);

-- Table: providers
CREATE TABLE providers (
    Provider_ID INT PRIMARY KEY,
    Provider_Name VARCHAR(100) NOT NULL,
    Provider_Gender VARCHAR(10) NOT NULL,
    Provider_Nationality VARCHAR(50) NOT NULL,
    Provider_Age INT NOT NULL,
    Provider_Image VARCHAR(255)
);

-- Level 2: patients (Depends on cities)

-- Table: patients
CREATE TABLE patients (
    Patient_ID INT PRIMARY KEY,
    Patient_Name VARCHAR(100) NOT NULL,
    Patient_Gender VARCHAR(10) NOT NULL,
    Patient_Age INT NOT NULL,
    City_ID INT NOT NULL,
    Patient_Race VARCHAR(50) NOT NULL
);

-- Level 3: visits (Main Fact Table - No FKs at creation time for speed)

-- Table: visits
CREATE TABLE visits (
    Visit_ID INT PRIMARY KEY,
    -- DATE_FORMAT for import: STR_TO_DATE(@Date_of_Visit, '%d/%m/%Y')
    Date_of_Visit DATE NOT NULL,
    Patient_ID INT NOT NULL,
    Provider_ID INT NOT NULL,
    Department_ID INT NOT NULL,
    Diagnosis_ID INT NOT NULL,
    Procedure_ID INT NOT NULL,
    Insurance_ID INT NOT NULL,
    Service_Type VARCHAR(50) NOT NULL,
    Treatment_Cost INT NOT NULL,
    Medication_Cost INT NOT NULL,
    Patient_Satisfaction INT NOT NULL,
    Referral_Source VARCHAR(50) NOT NULL,
    Emergency_Visit VARCHAR(5) NOT NULL,
    Payment_Status VARCHAR(50) NOT NULL,				 
    Room_Type VARCHAR(50) NULL,									   -- Room_Type can be NULL for 'Outpatient' visits
    Insurance_Coverage DECIMAL(10, 2) NOT NULL,
    Room_Charges_daily_rate INT NOT NULL
    -- Foreign Keys for this table will be added after data import.
);


-- -------------------------------------------------------------------
-- 3. Data Import from CSV Files
-- -------------------------------------------------------------------

-- Import all simple tables
LOAD DATA INFILE 'D:/____________/cities.csv'							 -- Use your file location
INTO TABLE cities
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'D:/____________/departments.csv'						 -- Use your file location
INTO TABLE departments
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'D:/____________/diagnoses.csv'						 -- Use your file location
INTO TABLE diagnoses
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'D:/____________/insurance.csv'						 -- Use your file location
INTO TABLE insurance
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'D:/____________/procedures.csv'						 -- Use your file location
INTO TABLE procedures
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'D:/____________/providers.csv'						 -- Use your file location
INTO TABLE providers
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'D:/____________/patients.csv'							 -- Use your file location
INTO TABLE patients
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS;

-- Import the visits table, handling the date format
LOAD DATA INFILE 'D:/____________/visits.csv'							 -- Use your file location
INTO TABLE visits
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
-- Use a user-defined variable (@Date_of_Visit) to read the string 
-- and then convert it using STR_TO_DATE for the correct format ('%d/%m/%Y')
(@dummy, @Date_of_Visit, @Patient_ID, @Provider_ID, @Department_ID, @Diagnosis_ID, @Procedure_ID, @Insurance_ID, @Service_Type, @Treatment_Cost, @Medication_Cost, @Patient_Satisfaction, @Referral_Source, @Emergency_Visit, @Payment_Status, @Room_Type, @Insurance_Coverage, @Room_Charges_daily_rate)
SET Date_of_Visit = STR_TO_DATE(@Date_of_Visit, '%e/%c/%Y');


-- -------------------------------------------------------------------
-- 4. Add Foreign Keys to patients and visits table 
-- -------------------------------------------------------------------

-- Add all FKs to the patients table after the data has been imported
ALTER TABLE patients
ADD CONSTRAINT fk_patients_cities
    FOREIGN KEY (City_ID) REFERENCES cities(City_ID);
    
-- Add all FKs to the visits table after the data has been imported
ALTER TABLE visits
ADD CONSTRAINT fk_visits_patient
    FOREIGN KEY (Patient_ID) REFERENCES patients(Patient_ID),
ADD CONSTRAINT fk_visits_provider
    FOREIGN KEY (Provider_ID) REFERENCES providers(Provider_ID),
ADD CONSTRAINT fk_visits_department
    FOREIGN KEY (Department_ID) REFERENCES departments(Department_ID),
ADD CONSTRAINT fk_visits_diagnosis
    FOREIGN KEY (Diagnosis_ID) REFERENCES diagnoses(Diagnosis_ID),
ADD CONSTRAINT fk_visits_procedure
    FOREIGN KEY (Procedure_ID) REFERENCES procedures(Procedure_ID),
ADD CONSTRAINT fk_visits_insurance
    FOREIGN KEY (Insurance_ID) REFERENCES insurance(Insurance_ID);
    





