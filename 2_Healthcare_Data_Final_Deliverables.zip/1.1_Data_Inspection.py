"""
Python code for Data Loading and Inspection
A script to read all CSV files into a dictionary of pandas DataFrames and 
then print the first 5 rows (.head()) and the data types/non-null counts (.info()) for each file.
"""

import pandas as pd
import os

# 1. Define the list of all uploaded files (tables)
files = [
    "cities.csv",
    "departments.csv",
    "diagnoses.csv",
    "insurance.csv",
    "patients.csv",
    "procedures.csv",
    "providers.csv",
    "visits.csv"
]

# Dictionary to store all DataFrames for easy access
dataframes = {}

print("--- Starting Initial Data Inspection ---")

for file in files:
    try:
        # Create a clean DataFrame name (e.g., 'cities.csv' -> 'cities')
        df_name = file.replace(".csv", "")
        
        # Read the CSV file into a DataFrame
        df = pd.read_csv(file)
        dataframes[df_name] = df
        
        print(f"\n==================== {df_name.upper()} TABLE ====================")
        
        # 2. Perform initial inspection: .head()
        print(f"Top 5 Rows ({df_name}.head()):")
        print(df.head())
        
        # 3. Perform initial inspection: .info()
        print(f"\nStructure and Data Types ({df_name}.info()):")
        df.info()
        
        # 4. Check for unique IDs to confirm Primary Keys
        pk_col = [col for col in df.columns if col.endswith('_ID') or col.endswith('ID')][0] if any(col.endswith('_ID') or col.endswith('ID') for col in df.columns) else 'N/A'
        if pk_col != 'N/A':
            is_pk = df[pk_col].nunique() == len(df)
            print(f"\nPotential Primary Key Check: '{pk_col}'")
            print(f"Total Rows: {len(df)}, Unique IDs: {df[pk_col].nunique()}. Is it a Primary Key? {is_pk}")
            
        print("-" * 50)
        
    except FileNotFoundError:
        print(f"ERROR: File '{file}' not found. Check your working directory.")
    except Exception as e:
        print(f"An error occurred while processing {file}: {e}")

# The loaded DataFrames can now be accessed via the dictionary: e.g., dataframes['visits']
print("\nData loading and initial inspection complete.")