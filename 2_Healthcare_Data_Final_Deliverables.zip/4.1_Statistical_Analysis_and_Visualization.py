     
"""
1. Descriptive Statistics for Key Financial and Quality Metrics	
Calculates basic statistics (mean, median, standard deviation, min/max) 
for Total_Cost and Patient_Satisfaction to understand the data's distribution and check for outliers.
"""

# Assuming df_analysis is loaded from the previous step

print("\n--- Descriptive Statistics ---")

# Select only the numerical columns we are interested in for statistical analysis
key_metrics = df_analysis[['Total_Cost', 'Treatment_Cost', 'Medication_Cost', 'Patient_Age', 'Patient_Satisfaction']]

# The .describe() method calculates all major descriptive statistics in one line
descriptive_stats = key_metrics.describe().T # .T transposes the table for better readability

print(descriptive_stats)

# --- Simple Outlier Check: The Max vs. 75th Percentile ---
print("\n--- Outlier Check (Max vs 75th Percentile) ---")
for col in key_metrics.columns:
    # IQR calculation is a simple way to flag potential outliers
    q3 = descriptive_stats.loc[col, '75%']
    maximum = descriptive_stats.loc[col, 'max']
    
    if maximum > (q3 * 1.5): # Simple rule of thumb for checking distance
        print(f"⚠️ {col}: Max ({maximum:.0f}) is significantly higher than 75th Percentile ({q3:.0f}). Potential outliers present.")
    else:
        print(f"✅ {col}: Distribution seems typical.")
        

"""
2. Correlation Matrix and Heatmap Visualization
Calculates the correlation between key numerical variables and visualizes the results using a heatmap. This easily identifies which factors (like Age, Cost, Satisfaction) are related.
"""

import seaborn as sns
import matplotlib.pyplot as plt

# --- 1. Select Numerical Data for Correlation ---
# Focus on the variables that drive cost and quality
corr_data = df_analysis[['Patient_Age', 'Total_Cost', 'Treatment_Cost', 'Medication_Cost', 'Patient_Satisfaction']]

# --- 2. Calculate the Correlation Matrix ---
# The .corr() method calculates Pearson's R correlation coefficients
correlation_matrix = corr_data.corr()

print("\n--- Correlation Matrix (R-values) ---")
print(correlation_matrix)

# --- 3. Create a Heatmap Visualization ---
plt.figure(figsize=(12, 9))
sns.heatmap(
    correlation_matrix,
    annot=True,        # Show the correlation value on the map
    cmap='coolwarm',   # Color scheme: cool=negative, warm=positive
    fmt=".2f",         # Format the numbers to two decimal places
    linewidths=.5,     # Add lines between cells for separation
    cbar=True          # Display the color bar
)
plt.title('Correlation Heatmap of Key Variables')
plt.savefig('correlation_heatmap.png') # Save the plot to a file
plt.close() # Close the plot to prevent it from showing immediately

print("\nSuccessfully generated 'correlation_heatmap.png'.")
print("Strong positive correlation (close to 1.0) means variables increase together.")
print("Strong negative correlation (close to -1.0) means one increases as the other decreases.")


"""
3. Average Total Cost Comparison by Service Type 
    Uses the groupby() function to calculate the average (mean) Total_Cost for each Service_Type (Inpatient vs. Outpatient).
"""

print("\n--- Average Total Cost by Service Type ---")

# 1. Group the data by 'Service_Type'
# 2. Select the 'Total_Cost' column
# 3. Calculate the mean() for each group
cost_by_service = df_analysis.groupby('Service_Type')['Total_Cost'].mean().reset_index()

# Rename the column for clear presentation
cost_by_service.columns = ['Service_Type', 'Average_Total_Cost']

print(cost_by_service)

# --- BONUS: Simple Visualization (Bar Chart) ---
import matplotlib.pyplot as plt

plt.figure(figsize=(6, 4))
plt.bar(cost_by_service['Service_Type'], cost_by_service['Average_Total_Cost'], color=['skyblue', 'lightcoral'])
plt.title('Average Total Cost by Service Type')
plt.ylabel('Average Total Cost ($)')
plt.savefig('avg_cost_by_service_type_bar.png')
plt.close()

print("\nSuccessfully generated 'avg_cost_by_service_type_bar.png'.")


"""
4. Visualizing Patient Satisfaction Distribution by Department (Box Plot)	
    Uses the seaborn library to create a Box Plot. This visualization shows the median, quartiles, and outliers of Patient_Satisfaction for every Department simultaneously.
"""

import seaborn as sns
import matplotlib.pyplot as plt

print("\n--- Distribution Analysis: Patient Satisfaction by Department ---")

# --- 1. Filter data for departments with enough visits (optional, but good practice) ---
# Check the number of visits per department to exclude tiny groups if needed
dept_counts = df_analysis['Department'].value_counts()
min_visits = 100 # Set a minimum threshold
departments_to_keep = dept_counts[dept_counts >= min_visits].index
df_filtered = df_analysis[df_analysis['Department'].isin(departments_to_keep)]

# --- 2. Create the Box Plot ---
plt.figure(figsize=(10, 6))
sns.boxplot(
    x='Department',
    y='Patient_Satisfaction',
    data=df_filtered,
    palette='Pastel2' # Nice color scheme
)
plt.title('Patient Satisfaction Distribution Across Departments')
plt.xlabel('Department')
plt.ylabel('Patient Satisfaction Score')
plt.xticks(rotation=45, ha='right') # Rotate X-axis labels to prevent overlap
plt.tight_layout() # Adjust layout to ensure everything fits
plt.savefig('satisfaction_by_department_boxplot.png')
plt.close()

print("\nSuccessfully generated 'satisfaction_by_department_boxplot.png'.")