"""
1. Database Connection and Analysis DataFrame Creation	
    Connects Python to the MySQL database and executes a single SQL query 
    to join the central visits table with key demographic and lookup tables 
    (patients, providers, departments).
"""

import mysql.connector
import pandas as pd

# --- 1. Connection Parameters ---
DB_HOST = "127.0.0.1"                   # MySQL credentials
DB_USER = "root"                        # MySQL credentials
DB_PASSWORD = "Chha1985!" 
DB_NAME = "healthcare_data"             # The database created in MySQL


# --- 2. SQL Query to Join and Select Data ---
# In Python, the SQL code is assigned to a variable named 'sql_query'
sql_query = """
SELECT
    v.Visit_ID,
    v.Date_of_Visit,
    v.Service_Type,
    v.Treatment_Cost,
    v.Medication_Cost,
    (v.Treatment_Cost + v.Medication_Cost) AS Total_Cost,
    v.Patient_Satisfaction,
    p.Patient_Gender,
    p.Patient_Age,
    p.Patient_Race,
    pr.Provider_Gender,
    d.Department
FROM
    visits v
JOIN patients p ON v.Patient_ID = p.Patient_ID
JOIN providers pr ON v.Provider_ID = pr.Provider_ID
JOIN departments d ON v.Department_ID = d.Department_ID;
"""

try:
    # Establish the connection
    conn = mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )
    
    # Use pandas to read the results of the SQL query directly into a DataFrame
    df_analysis = pd.read_sql(sql_query, conn)
    
    print("Database connection successful. Data loaded into 'df_analysis' DataFrame.")
    print("\nDataFrame Head:")
    print(df_analysis.head())
    
except mysql.connector.Error as err:
    print(f"Error connecting to MySQL: {err}")
    df_analysis = None # Ensure DataFrame is None if connection fails
    
finally:
    # Always close the connection, whether it failed or succeeded
    if 'conn' in locals() and conn.is_connected():
        conn.close()
        
