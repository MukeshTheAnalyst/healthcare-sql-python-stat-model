-- -------------------------------------------------------------------
-- 1. Data Cleaning: Standardize Patient Names
-- -------------------------------------------------------------------
-- Brief description of the code:
-- This query uses a series of nested REPLACE functions to clean the 
-- 'Patient_Name' column in the 'patients' table. It targets the 
-- common non-standard separators like '_' and '.' and replaces them 
-- with a single space ' '.

-- Display patient names with symbol '_' and '.'
SELECT Patient_Name
FROM patients
WHERE INSTR(Patient_Name, '_') > 0
   OR INSTR(Patient_Name, '.') > 0;
    
-- Replace extra symbols '_', and '.' with ' ' (space)
UPDATE patients
SET Patient_Name =     
    REPLACE(						-- 2. Outer Replace '.' with ' '        
        REPLACE(					-- 1. Inner Replace '_' with ' '
            Patient_Name, '_', ' '
        ), 
        '.', ' '
    );
    
    
    