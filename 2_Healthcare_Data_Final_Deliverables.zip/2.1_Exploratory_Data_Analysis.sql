-- -------------------------------------------------------------------
-- Exploratory Data Analysis of Healthcare Data
-- -------------------------------------------------------------------

/* 
1. 	Total Revenue and Volume by Service Type (Using CASE statement)	
	Calculates the total count, total revenue (Treatment_Cost + Medication_Cost), 
	and average revenue for each Service_Type (Inpatient vs. Outpatient).
*/ 

SELECT
    v.Service_Type,
    COUNT(v.Visit_ID) AS Total_Visits,
    -- Calculate total revenue as Treatment Cost + Medication Cost
    SUM(v.Treatment_Cost + v.Medication_Cost) AS Total_Revenue,
    -- Calculate the average total cost per visit
    AVG(v.Treatment_Cost + v.Medication_Cost) AS Avg_Revenue_Per_Visit
FROM
    visits v
GROUP BY
    v.Service_Type
ORDER BY
    Total_Revenue DESC;
    
/*
2. 	Top 5 Most Common Diagnoses and Average Patient Age	
	Identifies the top 5 most frequently occurring diagnoses and 
	determines the average age of patients for each of those diagnoses.
*/

SELECT
    d.Diagnosis,
    COUNT(v.Visit_ID) AS Diagnosis_Count,
    AVG(p.Patient_Age) AS Avg_Patient_Age
FROM
    visits v
JOIN
    diagnoses d ON v.Diagnosis_ID = d.Diagnosis_ID
JOIN
    patients p ON v.Patient_ID = p.Patient_ID
GROUP BY
    d.Diagnosis
ORDER BY
    Diagnosis_Count DESC
LIMIT 5;

/*
3. 	Monthly Trend of Visits (Date Functions and Subquery)	
	Groups the visit data by month and year to track the volume of visits over time, 
    which helps identify seasonal trends or growth patterns.
*/

/*
SELECT
    -- Use YEAR() and MONTHNAME() to format the date for reporting
    YEAR(Date_of_Visit) AS Visit_Year,
    MONTHNAME(Date_of_Visit) AS Visit_Month,
    COUNT(Visit_ID) AS Total_Visits
FROM
    visits
GROUP BY
    YEAR(Date_of_Visit),
    MONTH(Date_of_Visit)
ORDER BY
    YEAR(Date_of_Visit),
    MONTH(Date_of_Visit); -- Use MONTH() for correct chronological ordering

this gives Error Code : 1055 - MySQL is running in strict ONLY_FULL_GROUP_BY mode (which enforces exact column/functional dependence rules).
*/

-- 100% Strict-Mode-Safe Version
-- You can solve this by computing your derived fields in a subquery, then grouping by those aliases in the outer query:

SELECT
    Visit_Year,
    Visit_Month,
    COUNT(Visit_ID) AS Total_Visits
FROM (
    SELECT
        Visit_ID,
        YEAR(Date_of_Visit) AS Visit_Year,
        MONTHNAME(Date_of_Visit) AS Visit_Month,
        MONTH(Date_of_Visit) AS Visit_Month_Num
    FROM visits
) AS sub
GROUP BY
    Visit_Year,
    Visit_Month,
    Visit_Month_Num
ORDER BY
    Visit_Year,
    Visit_Month_Num;
    
/*
4.	Top 3 Most Expensive Procedures	
	Calculates the total accumulated cost (Treatment + Medication) for each procedure and 
    ranks them to find the most expensive ones by total spend.
*/

SELECT
    p.Procedure_Name,
    SUM(v.Treatment_Cost + v.Medication_Cost) AS Total_Spend,
    AVG(v.Treatment_Cost + v.Medication_Cost) AS Avg_Cost_Per_Procedure
FROM
    visits v
JOIN
    procedures p ON v.Procedure_ID = p.Procedure_ID
GROUP BY
    p.Procedure_Name
ORDER BY
    Total_Spend DESC
LIMIT 3;
    
/*
5. Top Providers by Patient Satisfaction  (Aggregate & Join)
	Ranks providers based on their average Patient_Satisfaction score, 
    but only includes providers who have attended to a minimum number of visits 
    (e.g., 50) to ensure the rating is statistically reliable.
*/

SELECT
    pr.Provider_Name,
    COUNT(v.Visit_ID) AS Total_Visits_Count,
    -- Round the average satisfaction score to 2 decimal places
    ROUND(AVG(v.Patient_Satisfaction), 2) AS Avg_Satisfaction_Score
FROM
    visits v
JOIN
    providers pr ON v.Provider_ID = pr.Provider_ID
GROUP BY
    pr.Provider_Name
HAVING
    -- Filter to include only providers with significant visit count (e.g., 50+)
    COUNT(v.Visit_ID) >= 50
ORDER BY
    Avg_Satisfaction_Score DESC,
    Total_Visits_Count DESC;

/*
6. Insurance Coverage vs. Total Cost by Insurance Provider (CASE statement) 
	Analyzes the efficiency of each insurance provider by calculating 
    the total cost, total amount covered, and the average coverage percentage.
*/

SELECT
    i.Insurance_Provider,
    COUNT(v.Visit_ID) AS Visit_Count,
    SUM(v.Treatment_Cost + v.Medication_Cost) AS Total_Gross_Cost,
    SUM(v.Insurance_Coverage) AS Total_Covered,
    -- Calculate the average percentage of the gross cost that is covered
    ROUND(AVG(v.Insurance_Coverage / (v.Treatment_Cost + v.Medication_Cost) * 100), 2) AS Avg_Coverage_Percentage
FROM
    visits v
JOIN
    insurance i ON v.Insurance_ID = i.Insurance_ID
GROUP BY
    i.Insurance_Provider
ORDER BY
    Total_Gross_Cost DESC;
    
  
/*
7. Identifying High-Cost Patients (Window Function: RANK)	
	Uses a Window Function (RANK()) within a CTE (HighCostRankedVisits) 
    to find the top 5 patients with the highest single-visit total cost.
*/

WITH HighCostRankedVisits AS (
    SELECT
        p.Patient_ID,
        p.Patient_Name,
        v.Visit_ID,
        (v.Treatment_Cost + v.Medication_Cost) AS Total_Visit_Cost,
        -- RANK() is the Window Function used here
        RANK() OVER (ORDER BY (v.Treatment_Cost + v.Medication_Cost) DESC) as Cost_Rank
    FROM
        visits v
    JOIN
        patients p ON v.Patient_ID = p.Patient_ID
)
SELECT
    Cost_Rank,
    Patient_ID,
    Patient_Name,
    Total_Visit_Cost
FROM
    HighCostRankedVisits
WHERE
    Cost_Rank <= 5;

/*
8. Department Performance (Average Satisfaction & Cost) 	
	Compares departments based on two key metrics: average patient satisfaction and average total cost.
*/

SELECT
    d.Department,
    COUNT(v.Visit_ID) AS Total_Visits,
    ROUND(AVG(v.Patient_Satisfaction), 2) AS Avg_Satisfaction,
    ROUND(AVG(v.Treatment_Cost + v.Medication_Cost), 2) AS Avg_Total_Cost
FROM
    visits v
JOIN
    departments d ON v.Department_ID = d.Department_ID
GROUP BY
    d.Department
ORDER BY
    Avg_Satisfaction DESC;

/*
9. Percentage of Emergency Visits by Gender (CASE and Aggregation)	
	Calculates the total percentage of visits that were marked as emergency 
    for both male and female patients.
*/

SELECT
    p.Patient_Gender,
    COUNT(v.Visit_ID) AS Total_Visits,
    -- Use SUM with a CASE expression to count only emergency visits
    SUM(CASE WHEN v.Emergency_Visit = 'Yes' THEN 1 ELSE 0 END) AS Total_Emergency_Visits,
    -- Calculate the percentage of visits that were an emergency
    (SUM(CASE WHEN v.Emergency_Visit = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(v.Visit_ID)) AS Pct_Emergency_Visits
FROM
    visits v
JOIN
    patients p ON v.Patient_ID = p.Patient_ID
GROUP BY
    p.Patient_Gender;

/*
10. Most Popular Procedure for the Top Diagnosis (Subquery)	
	Uses a subquery to first find the single most frequent diagnosis and 
    then finds the most popular procedure associated with that specific diagnosis.
*/

SELECT
    p.Procedure_Name,
    COUNT(v.Visit_ID) AS Procedure_Count
FROM
    visits v
JOIN
    procedures p ON v.Procedure_ID = p.Procedure_ID
WHERE
    v.Diagnosis_ID = (
        -- Subquery 1: Find the Diagnosis_ID for the most frequent diagnosis
        SELECT
            Diagnosis_ID
        FROM
            visits
        GROUP BY
            Diagnosis_ID
        ORDER BY
            COUNT(Visit_ID) DESC
        LIMIT 1
    )
GROUP BY
    p.Procedure_Name
ORDER BY
    Procedure_Count DESC
LIMIT 2;